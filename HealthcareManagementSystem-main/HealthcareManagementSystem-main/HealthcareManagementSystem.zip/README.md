# HealthcareManagementSystem
A Project done by us for Healthcare Management System for Organizational Healthcare
This Project is done using Asp.Net Framework MVC
> This project is done by us.
### Prerequisites for running the application
* Visual studio 2019 or above
* Sql server 2014 or above
* Windows operating system
---
> Default admin Credentials
``` admin@demo.com ```
``` Admin@123 ```
---
Default password for any new user entered by admin is User@123. The User can change it himself later
> There is an admin and four roles entered into the datbase by default

---
#### Project done by
* [Ann Liya](https://github.com/Ann2124)
* [Mounika](https://github.com/mounika-max)
* [Sucheta](https://github.com/Suchi20-git)
* [Rakesh Kumar T](https://github.com/rakesh-kumar-t)
---
